import argparse
import asyncio
import base64
import logging

import httpx

import gallagher_restapi

_LOGGER = logging.getLogger(__name__)


async def main(host: str, port: int, api_key: str) -> None:
    """Test connecting to Gallagher REST api."""
    httpx_client = httpx.AsyncClient(verify=False)
    try:

        # if cardholder := await cardholder_client.get_cardholder(name="Rami"):
        #     print(cardholder[0].first_name)
        cardholder_client = gallagher_restapi.CardholderClient(
            host=host,
            port=port,
            api_key=api_key,
            httpx_client=httpx_client,
        )
        await cardholder_client.authenticate()
        if cardholder := await cardholder_client.get_cardholder(name="Rami"):
            print(cardholder[0].last_successful_access_time)
            print(cardholder[0].last_successful_access_zone.name)
            print(cardholder[0].access_groups[0].access_group.name)
            print(cardholder[0].cards[0].__dict__)
        event_client = gallagher_restapi.EventClient(
            host=host,
            port=port,
            api_key=api_key,
            httpx_client=httpx_client,
        )
        await event_client.authenticate()
        await event_client.get_event_types()
        event_filter = gallagher_restapi.EventFilter(
            top=5,
            previous=True,
            event_types=[20001],
            fields=["defaults", "door", "cardholder.pdf_987"],
        )
        entry_exit_events = await event_client.get_events(filter=event_filter)
        for event in entry_exit_events:
            # for event in new_events:
            print(event.__dict__)
    except gallagher_restapi.GllApiError as err:
        _LOGGER.error(err)
    finally:
        if httpx_client is not None:
            await httpx_client.aclose()


# async def authenticate():
#     gllclient = Client("192.168.55.27", "434F-8FAF-4684-A589-BCCA-C5B7-6001-52DB")
#     await gllclient.authenticate()
#     if gllclient.is_connected:

# pdfs = [pdf async for pdf in gllclient.get_personal_data_field()]
# print(pdfs)
# async for pdf in pdfs:
#     print(vars(pdf))
#     if pdf.name == "Mobile2":
#         break
# pdf_name = ""
# for pdf in pdfs:
#     if pdf.type == FTPersonalDataFieldType.IMAGE:
#         pdf_name = pdf.name
# cardholders = gllclient.get_cardholder(
#     pdfs={'"Mobile1"': "rami.mousleh@gallagher-me.com"}
# )
# async for cardholder in cardholders:
#     if cardholder:
#         print(cardholder.id)
#         if cardholder.id == 360:
#             print(vars(cardholder))
#             break
# async for cardholder in gllclient.get_cardholder(id=378):
#     print(cardholder)

# primary_fiels = {"firstName": "Rami"}
# with open("rami.jpeg", "rb") as file:
#     image = file.read()
# b64_string = base64.b64encode(image).decode()
# image_pdfs = {"Photo": b64_string}
# string_pdfs = {"Mobile2": "+971222222"}
# await gllclient.edit_cardholder(
#     cardholder,
#     primary_fields=primary_fiels,
#     image_pdfs=image_pdfs,
#     string_pdfs=string_pdfs,
# )
# print(vars(cardholders))
# print(cardholder[0].lastName)
# # print(cardholders[0].personalDataDefinitions["@Photo"].value.href)
# print(cardholder[0].personalDataDefinitions[pdf_name])
# image = await gllclient.get_cardholder_image(
#     cardholder[0].personalDataDefinitions[pdf_name]
# )
# with open("rami.jpeg", "rb") as file:
#     image = file.read()
# # b64_string = str(base64.b64encode(image))
# # print(type(b64_string))
# # print(b64_string)
# # try:
# await gllclient.edit_cardholder(
#     cardholder[0], {f"@{pdf_name}": base64.b64encode(image).decode()}
# )
# except GllApiError as err:
# print(err)
# print(response)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("host", type=str)
    parser.add_argument("port", type=int)
    parser.add_argument("api_key", type=str)
    args = parser.parse_args()

    LOG_LEVEL = logging.INFO
    # if args.debug:
    #     LOG_LEVEL = logging.DEBUG
    logging.basicConfig(format="%(message)s", level=LOG_LEVEL)

    try:

        asyncio.run(main(host=args.host, port=args.port, api_key=args.api_key))
    except KeyboardInterrupt:
        pass

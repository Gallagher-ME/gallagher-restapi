"""Gallagher REST api python client."""
import asyncio
import logging
from typing import AsyncIterator

from . import Client
from .event_filter import EventFilter
from .models.event import FTEvent, FTEventGroup, FTEventType

_LOGGER = logging.getLogger(__name__)

MOVEMENT_EVENT_TYPES = [20001, 20002, 20003, 20047, 20107, 42415]


class EventClient:
    """REST api event client for Gallagher Command Center."""

    def __init__(self, client: Client) -> None:
        """Initialize event client."""
        self.client = client
        self.client.httpx_client.timeout.read = None
        self.event_groups: dict[str, FTEventGroup] = {}
        self.event_types: dict[str, FTEventType] = {}

    async def get_event_types(self) -> None:
        """Return list of event types."""
        response = await self.client._async_request(
            "GET", self.client.api_features.events_features.event_groups.href
        )
        self.event_groups = {
            FTEventGroup(event_group).name: FTEventGroup(event_group)
            for event_group in response["eventGroups"]
        }
        for event_group in self.event_groups.values():
            self.event_types.update(
                {event_type.name: event_type for event_type in event_group.event_types}
            )

    async def get_events(self, filter: EventFilter | None = None) -> list[FTEvent]:
        """Return list of events filtered by params."""
        events: list[FTEvent] = []
        if response := await self.client._async_request(
            "GET",
            self.client.api_features.events_features.events.href,
            params=filter.params if filter else None,
        ):
            events = [FTEvent(event) for event in response["events"]]
        return events

    async def get_new_events(
        self, filter: EventFilter | None = None
    ) -> AsyncIterator[list[FTEvent]]:
        """Yield a list of new events filtered by params."""
        response = await self.client._async_request(
            "GET",
            self.client.api_features.events_features.updates.href,
            params=filter.params if filter else None,
        )
        while True:
            _LOGGER.debug(response)
            yield [FTEvent(event) for event in response["events"]]
            await asyncio.sleep(1)
            response = await self.client._async_request(
                "GET",
                response["updates"]["href"],
                params=filter.params if filter else None,
            )

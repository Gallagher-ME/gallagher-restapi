"""The exceptions raised by the api."""


class GllApiError(Exception):
    """General GllApi exception occurred."""


class ConnectError(GllApiError):
    """General GllApi exception occurred."""


class PatchError(GllApiError):
    """Error in patch body content."""


class Unauthorized(GllApiError):
    """Authentication failed."""

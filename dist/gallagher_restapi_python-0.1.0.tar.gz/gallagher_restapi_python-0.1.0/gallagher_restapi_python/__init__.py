"""Gallagher REST api python library."""
import logging
from typing import Any

import httpx
from ssl import SSLError

from .exceptions import ConnectError, GllApiError, PatchError, Unauthorized
from .api_features import FTApiFeatures

_LOGGER = logging.getLogger(__name__)


class Client:
    """REST api cardholder client for Gallagher Command Center."""

    def __init__(
        self,
        host: str = "localhost",
        port: int = 8904,
        api_key: str = "",
        httpx_client: httpx.AsyncClient | None = None,
    ) -> None:
        """Initialize REST api client."""
        self.server_url = f"https://{host}:{port}"
        self.api_key = f"GGL-API-KEY {api_key}"
        self.is_connected = False
        self.api_features: FTApiFeatures
        self.item_types: dict = {}
        self.httpx_client: httpx.AsyncClient = httpx_client or httpx.AsyncClient()
        self.httpx_client.headers = httpx.Headers({"Authorization": self.api_key})

    async def _async_request(
        self, method: str, endpoint: str, params: dict[str, str] | None = None
    ) -> Any:
        """Send a http request and return the response."""
        _LOGGER.info("Sending request to endpoint: %s, params: %s", endpoint, params)
        try:
            response = await self.httpx_client.request(method, endpoint, params=params)
        except (httpx.ConnectError, SSLError) as err:
            raise ConnectError(
                f"Connection failed while sending request: {err}"
            ) from err
        if response.status_code == httpx.codes.UNAUTHORIZED:
            raise Unauthorized
        if response.status_code != httpx.codes.OK:
            raise GllApiError(response.text)
        _LOGGER.info("Response: %s", response.text)
        return response.json()

    async def authenticate(self):
        """Connect to Server to authenticate."""
        response = await self._async_request("GET", f"{self.server_url}/api/")
        self.api_features = FTApiFeatures(response["features"])

"""Gallagher REST api features."""

from typing import Any

from .models import FTNavigation


class FTApiFeaturesEvents:
    """FTApiFeature events class."""

    def __init__(self, features: dict[str, Any]) -> None:
        """Initialize FTApiFeature events."""
        self.events = FTNavigation(features["events"])
        self.updates = FTNavigation(features["updates"])
        self.event_groups = FTNavigation(features["eventGroups"])
        self.divisions = FTNavigation(features["divisions"])


class FTApiFeaturesAlarms:
    """FTApiFeature alarms class."""

    def __init__(self, features: dict[str, Any]) -> None:
        """Initialize FTApiFeature alarms."""
        self.alarms = FTNavigation(features["alarms"])
        self.updates = FTNavigation(features["updates"])
        self.divisions = FTNavigation(features["divisions"])


class FTApiFeatures:
    """FTApiFeatures base class."""

    def __init__(self, features: dict[str, Any]) -> None:
        """Create list of supported features."""
        self.items = FTNavigation(features["items"]["items"])
        self.item_types = FTNavigation(features["items"]["itemTypes"])
        self.alarms_features = FTApiFeaturesAlarms(features["alarms"])
        self.events_features = FTApiFeaturesEvents(features["events"])
        self.cardholders = FTNavigation(features["cardholders"]["cardholders"])
        self.doors = FTNavigation(features["doors"]["doors"])
        self.personal_data_fields = FTNavigation(
            features["personalDataFields"]["personalDataFields"]
        )

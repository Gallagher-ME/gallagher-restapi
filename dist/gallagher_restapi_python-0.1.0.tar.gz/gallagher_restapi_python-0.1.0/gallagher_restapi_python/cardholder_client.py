"""Gallagher REST api python client."""
import base64
import binascii
from typing import Any

from . import Client
from .exceptions import GllApiError
from .models.cardholder import FTCardholder, FTCardholderPdfValue, FTItem, FTNavigation


class CardholderClient:
    """REST api cardholder client for Gallagher Command Center."""

    def __init__(self, client: Client) -> None:
        """Initialize cardholder client."""
        self.client = client

    async def get_item_types(self):
        """Get FTItem types."""
        item_types = await self.client._async_request(
            "GET", self.api_features.item_types.href
        )
        if item_types.get("itemTypes"):
            for item_type in item_types["itemTypes"]:
                self.item_types.update({item_type["name"]: item_type["id"]})

    async def get_personal_data_field(self, name: str | None = None) -> list[FTItem]:
        """Return List of available personal data fields."""
        pdfs: list[FTItem] = []
        params = {}
        if name:
            params = {"name": name}

        if response := await self.client._async_request(
            "GET", self.client.api_features.personal_data_fields.href, params=params
        ):
            pdfs = [FTItem(pdf) for pdf in response]

        return pdfs

    async def get_cardholder(
        self,
        ftitem_id: int | None = None,
        name: str | None = None,
        pdfs: dict[str, str] | None = None,
    ) -> list[FTCardholder]:
        """Return list of cardholders."""
        cardholders: list[FTCardholder] = []
        if ftitem_id:
            response: dict[str, Any] = await self.client._async_request(
                "GET", f"{self.client.api_features.cardholders.href}/{ftitem_id}"
            )
            if response:
                return [FTCardholder(response["results"])]

        else:
            if name and not isinstance(name, str):
                raise ValueError("name field must be a string value.")
            if pdfs and not isinstance(pdfs, dict):
                raise ValueError("pdfs field must be a dict.")
            params = {}
            if name:
                params = {"name": name}

            if pdfs:
                for name, value in pdfs.items():
                    if not (name.startswith('"') and name.endswith('"')):
                        name = f'"{name}"'
                    # if pdf name is correct we expect the result to include one item only
                    if not (pdf_field := await self.get_personal_data_field(name=name)):
                        raise GllApiError(f"pdf field: {name} not found")
                    params.update({f"pdf_{pdf_field[0].ftitem_id}": value})

            response = await self.client._async_request(
                "GET", self.client.api_features.cardholders.href, params=params
            )
            if response["results"]:
                for cardholder in response["results"]:
                    cardholder_details = await self.client._async_request(
                        "GET", cardholder["href"]
                    )
                    cardholders.append(FTCardholder(cardholder_details))
        return cardholders

    # async def get_cardholder_image(self, pdfValue: FTCardholderPdfValue):
    #     """Return base64 encoded image string."""
    #     if not (
    #         isinstance(pdfValue, FTCardholderPdfValue)
    #         and pdfValue.definition.type == FTPersonalDataFieldType.IMAGE
    #         and isinstance(pdfValue.value, FTNavigation)
    #     ):
    #         raise GllApiError("pdfValue isn't a valid image pdf.")
    #     return await self.get(pdfValue.value.href)

    # async def edit_cardholder(
    #     self,
    #     cardholder: FTCardholder,
    #     primary_fields: dict = None,
    #     string_pdfs: dict = None,
    #     image_pdfs: dict = None,
    # ) -> bool:
    #     "Edit existing cardholder details."
    #     if not isinstance(cardholder, FTCardholder):
    #         raise GllApiError("cardholder item must be of type FTCardholder")
    #     if primary_fields and not isinstance(primary_fields, dict):
    #         raise GllApiError("primary_fields should be a dict")
    #     if string_pdfs and not isinstance(string_pdfs, dict):
    #         raise GllApiError("string_pdfs must be a dictionary")
    #     if image_pdfs and isinstance(image_pdfs, dict):
    #         for key, value in image_pdfs.items():
    #             try:
    #                 base64.b64decode(value)
    #             except (TypeError, binascii.Error) as err:
    #                 raise GllApiError("Image pdf value must be base64 encoded.")
    #     params = {}
    #     if primary_fields:
    #         params.update(primary_fields)
    #     if string_pdfs:
    #         for key, value in string_pdfs.items():
    #             if not key[0] == "@":
    #                 params.update({f"@{key}": value})
    #             else:
    #                 params.update({key: value})
    #     if image_pdfs:
    #         for key, value in image_pdfs.items():
    #             if not key[0] == "@":
    #                 params.update({f"@{key}": value})
    #             else:
    #                 params.update({key: value})

    #     return await self.patch(cardholder.href, params=params)

"""Event filter for searching events."""

from datetime import datetime
from typing import Any

from .models import FTCardholder, FTEventGroup, FTEventType, FTItem

EVENT_FIELDS = [
    "defaults",
    "details",
    "href",
    "id",
    "serverDisplayName",
    "time",
    "message",
    "occurrences",
    "priority",
    "alarm",
    "operator",
    "source",
    "group",
    "type",
    "eventType",
    "division",
    "cardholder",
    "entryAccessZone",
    "exitAccessZone",
    "door",
    "accessGroup",
    "card",
    "modifiedItem",
    "lastOccurrenceTime",
    "previous",
    "next",
    "updates",
]


class EventFilter:
    """Event filter class."""

    def __init__(
        self,
        top: int | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
        sources: list[FTItem] | list[int] | None = None,
        event_types: list[FTEventType] | list[int] | None = None,
        event_groups: list[FTEventGroup] | list[int] | None = None,
        cardholders: list[FTCardholder] | list[int] | None = None,
        divisions: list[FTItem] | list[int] | None = None,
        related_items: list[FTItem] | list[int] | None = None,
        fields: list[str] | None = None,
        previous: bool = False,
    ) -> None:
        """Initialize event filter."""
        self.params: dict[str, Any] = {"previous": previous}
        if top:
            self.params["top"] = top
        if after and (after_value := after.isoformat()):
            self.params["after"] = after_value
        if before and (before_value := before.isoformat()):
            self.params["after"] = before_value
        if sources:
            self.params["source"] = [
                source.ftitem_id if isinstance(source, FTItem) else source
                for source in sources
            ]
        if event_types:
            self.params["type"] = [
                event_type.ftitem_id
                if isinstance(event_type, FTEventType)
                else event_type
                for event_type in event_types
            ]
        if event_groups:
            self.params["group"] = [
                event_group.ftitem_id
                if isinstance(event_group, FTEventGroup)
                else event_group
                for event_group in event_groups
            ]
        if cardholders:
            self.params["cardholder"] = [
                cardholder.ftitem_id
                if isinstance(cardholder, FTCardholder)
                else cardholder
                for cardholder in cardholders
            ]
        if divisions:
            self.params["division"] = [
                division.ftitem_id if isinstance(division, FTItem) else division
                for division in divisions
            ]
        if related_items:
            self.params["relatedItem"] = [
                related_item.ftitem_id
                if isinstance(related_item, FTItem)
                else related_item
                for related_item in related_items
            ]
        if fields:
            for field in fields:
                if (
                    not field.startswith("cardholder.pdf_")
                    and field not in EVENT_FIELDS
                ):
                    raise ValueError(f"{field} is not a valid field")
            self.params["fields"] = ",".join(fields)

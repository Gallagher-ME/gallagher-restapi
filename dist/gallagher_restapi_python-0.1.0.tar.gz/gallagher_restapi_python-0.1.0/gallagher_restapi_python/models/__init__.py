"""Gallagher REST api models."""
from typing import Any


class FTItemReference:
    """FTItem reference class."""

    def __init__(self, kwargs: Any):
        """Initialize FTItemReference."""

        self.href: str = kwargs.get("href", "")


class FTNavigation(FTItemReference):
    """FTNavigation Class."""


class FTStatus:
    """FTStatus base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTStatus item."""
        self.value = kwargs["value"]
        self.type = kwargs["type"]


class FTItemType:
    """FTItemType base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTItem type."""
        self.ftitem_id = kwargs["id"]
        self.name: str = kwargs.get("name", "")


class FTItem(FTItemReference):
    """FTItem base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTItem."""
        super().__init__(kwargs)
        self.ftitem_id = kwargs["id"]
        self.name: str = kwargs.get("name", "")


class FTItemBase(FTItem):
    """FTItem base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTItem base."""
        super().__init__(kwargs)
        self.description: str | None = kwargs.get("description")
        self.short_name: str | None = kwargs.get("shortName")
        self.notes: str | None = kwargs.get("notes")
        self.division = FTItem(kwargs.get("division"))
        self.updates = FTNavigation(kwargs.get("updates"))


class FTLinkItem(FTItemReference):
    """FTLinkItem base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTItemLink item."""
        super().__init__(kwargs)
        self.name: str = kwargs.get("name", "")

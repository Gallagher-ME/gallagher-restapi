"""Gallagher REST api models."""
from typing import Any

from . import FTItem, FTItemBase, FTItemReference, FTLinkItem, FTNavigation, FTStatus


class FTPersonalDataField(FTItemBase):
    """FTPersonalDataField base class."""

    def __init__(self, kwargs: Any) -> None:
        """
        docstring
        """
        super().__init__(kwargs)
        self.type = kwargs["type"]
        self.default = kwargs.get("default")
        self.required = kwargs.get("required", False)
        self.unique = kwargs.get("unique", False)
        self.regex = kwargs.get("regex")
        self.regex_description = kwargs.get("regexDescription")
        self.access_groups: list[FTLinkItem] = []
        if access_groups := kwargs.get("accessGroups"):
            self.accessGroups = [
                FTLinkItem(access_group) for access_group in access_groups
            ]


class FTAccessGroupMembership(FTItemReference):
    """FTAccessGroupMembership base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTAccessGroupMembership item."""
        super().__init__(kwargs)
        self.status = FTStatus(kwargs["status"])
        self.access_group = FTLinkItem(kwargs["accessGroup"])
        self.active_from: str | None = None
        if active_from := kwargs.get("from"):
            self.active_from = active_from
        self.active_until: str | None = None
        if active_until := kwargs.get("until"):
            self.active_until = active_until


class FTCardholderCard(FTItemReference):
    """FTCardholder card base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTCardholder card item."""
        super().__init__(kwargs)
        self.number: str = kwargs["number"]
        self.card_serial_number: str | None = kwargs.get("cardSerialNumber")
        self.issue_level: int | None = kwargs.get("issueLevel")
        self.status = FTStatus(kwargs["status"])
        self.type = FTLinkItem(kwargs["type"])
        self.access_group: FTLinkItem | None = None
        if access_group := kwargs.get("accessGroups"):
            self.access_group = FTLinkItem(access_group)
        self.active_from: str | None = None
        if active_from := kwargs.get("from"):
            self.active_from = active_from
        self.active_until: str | None = None
        if active_until := kwargs.get("until"):
            self.active_until = active_until


class FTPersonalDataDefinition(FTItem):
    """FTPersonalDataDefinition base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTPersonalDataDefinition item."""
        super().__init__(kwargs)
        self.type = kwargs["type"]


class FTCardholderPdfValue(FTItemReference):
    """
    FTCardholderPdfValue base class.
    """

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTCardholderPdfValue item."""
        super().__init__(kwargs)
        self.definition = FTPersonalDataDefinition(kwargs["definition"])
        if value := kwargs.get("value"):
            if isinstance(value, dict):
                self.value = FTNavigation(value)
            else:
                self.value = value


class FTCardholderSummary(FTItem):
    """FTCardholder summary class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTCardholder item."""
        super().__init__(kwargs)
        self.name: str = kwargs.get("name", "")
        self.first_name: str = kwargs.get("firstName", "")
        self.last_name: str = kwargs.get("lastName", "")
        self.pdfs = {
            pdf_name[1:]: pdf_value
            for pdf_name, pdf_value in kwargs.items()
            if pdf_name.startswith("@")
        }


class FTCardholder(FTCardholderSummary):
    """FTCardholder details class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTCardholder item."""
        super().__init__(kwargs)
        self.authorized: bool = kwargs["authorised"]
        self.edit = FTNavigation(kwargs["edit"])
        self.updates = FTNavigation(kwargs["updates"])
        self.update_location = FTNavigation(kwargs["updateLocation"])

        self.last_successful_access_zone: FTLinkItem | None = None
        if last_access_zone := kwargs.get("lastSuccessfulAccessZone"):
            self.last_successful_access_zone = FTLinkItem(last_access_zone)

        self.last_successful_access_time: str | None = None
        if last_access_time := kwargs.get("lastSuccessfulAccessTime"):
            self.last_successful_access_time = last_access_time

        self.access_groups: list[FTAccessGroupMembership] = []
        if access_groups := kwargs.get("accessGroups"):
            self.access_groups = [
                FTAccessGroupMembership(access_group) for access_group in access_groups
            ]
        self.cards: list[FTCardholderCard] = []
        if cards := kwargs.get("cards"):
            self.cards = [FTCardholderCard(card) for card in cards]

        self.personal_data_definitions: dict[str, FTCardholderPdfValue] = {}
        if personal_data_definitions := kwargs.get("personalDataDefinitions")[0]:
            for pdf_value in personal_data_definitions.values():
                pdf_definition = FTCardholderPdfValue(pdf_value)
                self.personal_data_definitions.update(
                    {pdf_definition.definition.name: pdf_value}
                )

"""Gallagher REST api models."""
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from . import FTItem, FTItemReference, FTItemType, FTLinkItem
from .cardholder import FTCardholderSummary


class FTAlarm(FTItemReference):
    """FTAlarm summary class"""

    def __init__(self, kwargs: Any):
        """Initialize FTEvent."""
        super().__init__(kwargs)
        self.state: str = kwargs["state"]


class FTEventCard:
    """Event card details."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize Event card."""
        self.number: str = kwargs["number"]
        self.issue_level: int = kwargs["issueLevel"]
        self.facility_code: str = kwargs["facilityCode"]


class FTEventType(FTItem):
    """FTEvent type class."""


class FTEventGroup(FTItem):
    """FTEvent group class."""

    def __init__(self, kwargs: Any):
        """Initialize FTEvent group."""
        super().__init__(kwargs)
        self.event_types: list[FTEventType] = [
            FTEventType(event_type) for event_type in kwargs["eventTypes"]
        ]


@dataclass
class EventField:
    """Class to represent Event field."""

    key: str
    name: str
    value: Callable[[Any], Any] = lambda val: val


EVENT_FIELDS: tuple[EventField, ...] = (
    EventField(key="defaults", name="defaults"),
    EventField(key="details", name="details"),
    EventField(key="href", name="href"),
    EventField(key="ftitem_id", name="id"),
    EventField(
        key="serverDisplayName",
        name="serverDisplayName",
    ),
    EventField(key="message", name="message"),
    EventField(
        key="time",
        name="time",
        value=lambda val: datetime.fromisoformat(val[:-1]),
    ),
    EventField(
        key="occurrences",
        name="occurrences",
    ),
    EventField(
        key="priority",
        name="priority",
    ),
    EventField(
        key="alarm",
        name="alarm",
        value=lambda val: FTAlarm(val),
    ),
    EventField(
        key="operator",
        name="operator",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="source",
        name="source",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="group",
        name="group",
        value=lambda val: FTItemType(val),
    ),
    EventField(
        key="event_type",
        name="type",
        value=lambda val: FTItemType(val),
    ),
    EventField(
        key="event_type",
        name="type",
        value=lambda val: FTItemType(val),
    ),
    EventField(
        key="division",
        name="division",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="cardholder",
        name="cardholder",
        value=lambda val: FTCardholderSummary(val),
    ),
    EventField(
        key="entry_access_zone",
        name="entryAccessZone",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="exit_access_zone",
        name="exitAccessZone",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="door",
        name="door",
        value=lambda val: FTLinkItem(val),
    ),
    EventField(
        key="access_group",
        name="accessGroup",
        value=lambda val: FTItemReference(val),
    ),
    EventField(
        key="card",
        name="card",
        value=lambda val: FTEventCard(val),
    ),
    # EventField(
    #     key="modified_item",
    #     name="modifiedItem",
    #     value=lambda val: FTEventCard(val),
    # ),
    EventField(
        key="last_occurrence_time",
        name="lastOccurrenceTime",
    ),
    EventField(
        key="previous",
        name="previous",
    ),
    EventField(
        key="next",
        name="next",
    ),
    EventField(
        key="updates",
        name="updates",
    ),
)


class FTEvent:
    """FTEvent summary class."""

    def __init__(self, kwargs: Any):
        """Initialize FTEvent."""
        for event_field in EVENT_FIELDS:
            if event_field.name in kwargs:
                setattr(
                    self,
                    event_field.key,
                    event_field.value(kwargs[event_field.name]),
                )

"""Gallagher item models."""
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from collections.abc import Callable


class FTItemReference:
    """FTItem reference class."""

    def __init__(self, kwargs: dict[str, Any]) -> None:
        """Initialize FTItemReference."""

        self.href: str = kwargs.get("href", "")


class FTNavigation(FTItemReference):
    """FTNavigation Class."""


class FTStatus:
    """FTStatus base class."""

    def __init__(self, kwargs: dict[str, Any]) -> None:
        """Initialize FTStatus item."""
        self.value = kwargs["value"]
        self.type = kwargs["type"]


class FTItemType:
    """FTItemType base class."""

    def __init__(self, kwargs: dict[str, Any]) -> None:
        """Initialize FTItem type."""
        self.ftitem_id = kwargs["id"]
        self.name: str = kwargs.get("name", "")


class FTItem(FTItemReference):
    """FTItem base class."""

    def __init__(self, kwargs: dict[str, Any]) -> None:
        """Initialize FTItem."""
        super().__init__(kwargs)
        self.ftitem_id = kwargs["id"]
        self.name: str = kwargs.get("name", "")


# class FTItemBase(FTItem):
#     """FTItem base class."""

#     def __init__(self, kwargs: dict[str, Any]) -> None:
#         """Initialize FTItem base."""
#         super().__init__(kwargs)
#         self.description: str | None = kwargs.get("description")
#         self.short_name: str | None = kwargs.get("shortName")
#         self.notes: str | None = kwargs.get("notes")
#         self.division = FTItem(kwargs.get("division"))
#         self.updates = FTNavigation(kwargs.get("updates"))


class FTLinkItem(FTItemReference):
    """FTLinkItem base class."""

    def __init__(self, kwargs: dict[str, Any]) -> None:
        """Initialize FTItemLink item."""
        super().__init__(kwargs)
        self.name: str = kwargs.get("name", "")


class FTApiFeaturesEvents:
    """FTApiFeature events class."""

    def __init__(self, features: dict[str, Any]) -> None:
        """Initialize FTApiFeature events."""
        self.events = FTNavigation(features["events"])
        self.updates = FTNavigation(features["updates"])
        self.event_groups = FTNavigation(features["eventGroups"])
        self.divisions = FTNavigation(features["divisions"])


class FTApiFeaturesAlarms:
    """FTApiFeature alarms class."""

    def __init__(self, features: dict[str, Any]) -> None:
        """Initialize FTApiFeature alarms."""
        self.alarms = FTNavigation(features["alarms"])
        self.updates = FTNavigation(features["updates"])
        self.divisions = FTNavigation(features["divisions"])


class FTApiFeatures:
    """FTApiFeatures base class."""

    def __init__(self, features: dict[str, Any]) -> None:
        """Create list of supported features."""
        self.items = FTNavigation(features["items"]["items"])
        self.item_types = FTNavigation(features["items"]["itemTypes"])
        self.alarms_features = FTApiFeaturesAlarms(features["alarms"])
        self.events_features = FTApiFeaturesEvents(features["events"])
        self.cardholders = FTNavigation(features["cardholders"]["cardholders"])
        self.doors = FTNavigation(features["doors"]["doors"])
        self.personal_data_fields = FTNavigation(
            features["personalDataFields"]["personalDataFields"]
        )


# class FTPersonalDataField(FTItemBase):
#     """FTPersonalDataField base class."""

#     def __init__(self, kwargs: Any) -> None:
#         """
#         docstring
#         """
#         super().__init__(kwargs)
#         self.type = kwargs["type"]
#         self.default = kwargs.get("default")
#         self.required = kwargs.get("required", False)
#         self.unique = kwargs.get("unique", False)
#         self.regex = kwargs.get("regex")
#         self.regex_description = kwargs.get("regexDescription")
#         self.access_groups: list[FTLinkItem] = []
#         if access_groups := kwargs.get("accessGroups"):
#             self.accessGroups = [
#                 FTLinkItem(access_group) for access_group in access_groups
#             ]


class FTAccessGroupMembership(FTItemReference):
    """FTAccessGroupMembership base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTAccessGroupMembership item."""
        super().__init__(kwargs)
        self.status = FTStatus(kwargs["status"])
        self.access_group = FTLinkItem(kwargs["accessGroup"])
        self.active_from: str | None = None
        if active_from := kwargs.get("from"):
            self.active_from = active_from
        self.active_until: str | None = None
        if active_until := kwargs.get("until"):
            self.active_until = active_until


class FTCardholderCard(FTItemReference):
    """FTCardholder card base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTCardholder card item."""
        super().__init__(kwargs)
        self.number: str = kwargs["number"]
        self.card_serial_number: str | None = kwargs.get("cardSerialNumber")
        self.issue_level: int | None = kwargs.get("issueLevel")
        self.status = FTStatus(kwargs["status"])
        self.type = FTLinkItem(kwargs["type"])
        self.access_group: FTLinkItem | None = None
        if access_group := kwargs.get("accessGroups"):
            self.access_group = FTLinkItem(access_group)
        self.active_from: str | None = None
        if active_from := kwargs.get("from"):
            self.active_from = active_from
        self.active_until: str | None = None
        if active_until := kwargs.get("until"):
            self.active_until = active_until


class FTPersonalDataDefinition(FTItem):
    """FTPersonalDataDefinition base class."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTPersonalDataDefinition item."""
        super().__init__(kwargs)
        self.type = kwargs["type"]


class FTCardholderPdfValue(FTItemReference):
    """
    FTCardholderPdfValue base class.
    """

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTCardholderPdfValue item."""
        super().__init__(kwargs)
        self.definition = FTPersonalDataDefinition(kwargs["definition"])
        if value := kwargs.get("value"):
            if isinstance(value, dict):
                self.value = FTNavigation(value)
            else:
                self.value = value


# class FTCardholderSummary(FTItem):
#     """FTCardholder summary class."""

#     def __init__(self, kwargs: Any) -> None:
#         """Initialize FTCardholder item."""
#         super().__init__(kwargs)
#         self.name: str = kwargs.get("name", "")
#         self.first_name: str = kwargs.get("firstName", "")
#         self.last_name: str = kwargs.get("lastName", "")
#         self.pdfs = {
#             pdf_name[1:]: pdf_value
#             for pdf_name, pdf_value in kwargs.items()
#             if pdf_name.startswith("@")
#         }


@dataclass
class FTCardholderField:
    """Class to represent FTCardholder field."""

    key: str
    name: str
    value: Callable[[Any], Any] = lambda val: val


FTCARDHOLDER_FIELDS: tuple[FTCardholderField, ...] = (
    FTCardholderField(key="href", name="href"),
    FTCardholderField(key="ftitem_id", name="id"),
    FTCardholderField(key="name", name="name"),
    FTCardholderField(key="first_name", name="firstName"),
    FTCardholderField(key="last_name", name="lastName"),
    FTCardholderField(key="short_name", name="shortName"),
    FTCardholderField(key="description", name="description"),
    FTCardholderField(key="authorised", name="authorised"),
    FTCardholderField(
        key="last_successful_access_time",
        name="lastSuccessfulAccessTime",
        value=lambda val: datetime.fromisoformat(val[:-1]).astimezone(timezone.utc),
    ),
    FTCardholderField(
        key="last_successful_access_zone",
        name="lastSuccessfulAccessZone",
        value=lambda val: FTLinkItem(val),
    ),
    FTCardholderField(key="server_display_name", name="serverDisplayName"),
    FTCardholderField(
        key="division", name="division", value=lambda val: FTItemReference(val)
    ),
    FTCardholderField(key="disable_cipher_pad", name="disableCipherPad"),
    FTCardholderField(key="user_code", name="usercode"),
    FTCardholderField(key="operator_login_enabled", name="operatorLoginEnabled"),
    FTCardholderField(key="operator_username", name="operatorUsername"),
    FTCardholderField(key="operator_password", name="operatorPassword"),
    FTCardholderField(key="operator_password_expired", name="operatorPasswordExpired"),
    FTCardholderField(key="windows_login_enabled", name="windowsLoginEnabled"),
    FTCardholderField(key="windows_username", name="windowsUsername"),
    FTCardholderField(
        key="personal_data_definitions",
        name="personalDataDefinitions",
        value=lambda val: {
            pdf_name[1:]: FTCardholderPdfValue(pdf_value)
            for pdf_name, pdf_value in val.items()
        },
    ),
    FTCardholderField(
        key="cards",
        name="cards",
        value=lambda val: [FTCardholderCard(card) for card in val],
    ),
    FTCardholderField(
        key="access_groups",
        name="accessGroups",
        value=lambda val: [
            FTAccessGroupMembership(access_group) for access_group in val
        ],
    ),
    # FTCardholderField(
    #     key="operator_groups",
    #     name="operatorGroups",
    #     value=lambda val: [
    #         FTOperatorGroup(operator_group) for operator_group in val
    #     ],
    # ),
    # FTCardholderField(
    #     key="competencies",
    #     name="competencies",
    #     value=lambda val: [
    #         FTCompetency(competency) for competency in val
    #     ],
    # ),
    FTCardholderField(key="edit", name="edit", value=lambda val: FTItemReference(val)),
    FTCardholderField(
        key="update_location",
        name="updateLocation",
        value=lambda val: FTItemReference(val),
    ),
    FTCardholderField(key="notes", name="notes"),
    # FTCardholderField(key="notifications", name="notifications", value=lambda val: FTNotification(val)),
    FTCardholderField(key="relationships", name="relationships"),
    FTCardholderField(key="lockers", name="lockers"),
    FTCardholderField(key="elevatorGroups", name="elevatorGroups"),
    FTCardholderField(
        key="last_printed_or_encodedTime", name="lastPrintedOrEncodedTime"
    ),
    FTCardholderField(
        key="last_printed_or_encoded_issue_level", name="lastPrintedOrEncodedIssueLevel"
    ),
    FTCardholderField(key="redactions", name="redactions"),
)


class FTCardholder:
    """FTCardholder details class."""

    ftitem_id: str

    def __init__(self, kwargs: Any) -> None:
        """Initialize FTCardholder item."""
        self.pdfs = {
            pdf_name[1:]: pdf_value
            for pdf_name, pdf_value in kwargs.items()
            if pdf_name.startswith("@")
        }
        for cardholder_field in FTCARDHOLDER_FIELDS:
            if cardholder_field.name in kwargs:
                setattr(
                    self,
                    cardholder_field.key,
                    cardholder_field.value(kwargs[cardholder_field.name]),
                )


# class FTCardholder(FTCardholderSummary):
#     """FTCardholder details class."""

#     def __init__(self, kwargs: Any) -> None:
#         """Initialize FTCardholder item."""
#         super().__init__(kwargs)
#         self.authorized: bool = kwargs["authorised"]
#         self.edit = FTNavigation(kwargs["edit"])
#         self.updates = FTNavigation(kwargs["updates"])
#         self.update_location = FTNavigation(kwargs["updateLocation"])

#         self.last_successful_access_zone: FTLinkItem | None = None
#         if last_access_zone := kwargs.get("lastSuccessfulAccessZone"):
#             self.last_successful_access_zone = FTLinkItem(last_access_zone)

#         self.last_successful_access_time: str | None = None
#         if last_access_time := kwargs.get("lastSuccessfulAccessTime"):
#             self.last_successful_access_time = last_access_time

#         self.access_groups: list[FTAccessGroupMembership] = []
#         if access_groups := kwargs.get("accessGroups"):
#             self.access_groups = [
#                 FTAccessGroupMembership(access_group) for access_group in access_groups
#             ]
#         self.cards: list[FTCardholderCard] = []
#         if cards := kwargs.get("cards"):
#             self.cards = [FTCardholderCard(card) for card in cards]

#         self.personal_data_definitions: dict[str, FTCardholderPdfValue] = {}
#         if personal_data_definitions := kwargs.get("personalDataDefinitions")[0]:
#             for pdf_value in personal_data_definitions.values():
#                 pdf_definition = FTCardholderPdfValue(pdf_value)
#                 self.personal_data_definitions.update(
#                     {pdf_definition.definition.name: pdf_value}
#                 )


class FTAlarm(FTItemReference):
    """FTAlarm summary class"""

    def __init__(self, kwargs: Any):
        """Initialize FTEvent."""
        super().__init__(kwargs)
        self.state: str = kwargs["state"]


class FTEventCard:
    """Event card details."""

    def __init__(self, kwargs: Any) -> None:
        """Initialize Event card."""
        self.number: str = kwargs["number"]
        self.issue_level: int = kwargs["issueLevel"]
        self.facility_code: str = kwargs["facilityCode"]


class FTEventType(FTItem):
    """FTEvent type class."""


class FTEventGroup(FTItem):
    """FTEvent group class."""

    def __init__(self, kwargs: Any):
        """Initialize FTEvent group."""
        super().__init__(kwargs)
        self.event_types: list[FTEventType] = [
            FTEventType(event_type) for event_type in kwargs["eventTypes"]
        ]


@dataclass
class EventField:
    """Class to represent Event field."""

    key: str
    name: str
    value: Callable[[Any], Any] = lambda val: val


EVENT_FIELDS: tuple[EventField, ...] = (
    EventField(key="defaults", name="defaults"),
    EventField(key="details", name="details"),
    EventField(key="href", name="href"),
    EventField(key="ftitem_id", name="id"),
    EventField(
        key="serverDisplayName",
        name="serverDisplayName",
    ),
    EventField(key="message", name="message"),
    EventField(
        key="time",
        name="time",
        value=lambda val: datetime.fromisoformat(val[:-1]),
    ),
    EventField(
        key="occurrences",
        name="occurrences",
    ),
    EventField(
        key="priority",
        name="priority",
    ),
    EventField(
        key="alarm",
        name="alarm",
        value=lambda val: FTAlarm(val),
    ),
    EventField(
        key="operator",
        name="operator",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="source",
        name="source",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="group",
        name="group",
        value=lambda val: FTItemType(val),
    ),
    EventField(
        key="event_type",
        name="type",
        value=lambda val: FTItemType(val),
    ),
    EventField(
        key="event_type",
        name="type",
        value=lambda val: FTItemType(val),
    ),
    EventField(
        key="division",
        name="division",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="cardholder",
        name="cardholder",
        value=lambda val: FTCardholder(val),
    ),
    EventField(
        key="entry_access_zone",
        name="entryAccessZone",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="exit_access_zone",
        name="exitAccessZone",
        value=lambda val: FTItem(val),
    ),
    EventField(
        key="door",
        name="door",
        value=lambda val: FTLinkItem(val),
    ),
    EventField(
        key="access_group",
        name="accessGroup",
        value=lambda val: FTItemReference(val),
    ),
    EventField(
        key="card",
        name="card",
        value=lambda val: FTEventCard(val),
    ),
    # EventField(
    #     key="modified_item",
    #     name="modifiedItem",
    #     value=lambda val: FTEventCard(val),
    # ),
    EventField(
        key="last_occurrence_time",
        name="lastOccurrenceTime",
    ),
    EventField(
        key="previous",
        name="previous",
    ),
    EventField(
        key="next",
        name="next",
    ),
    EventField(
        key="updates",
        name="updates",
    ),
)


class FTEvent:
    """FTEvent summary class."""

    def __init__(self, kwargs: Any):
        """Initialize FTEvent."""
        for event_field in EVENT_FIELDS:
            if event_field.name in kwargs:
                setattr(
                    self,
                    event_field.key,
                    event_field.value(kwargs[event_field.name]),
                )


class EventFilter:
    """Event filter class."""

    def __init__(
        self,
        top: int | None = None,
        after: datetime | None = None,
        before: datetime | None = None,
        sources: list[FTItem] | list[int] | None = None,
        event_types: list[FTEventType] | list[int] | None = None,
        event_groups: list[FTEventGroup] | list[int] | None = None,
        cardholders: list[FTCardholder] | list[int] | None = None,
        divisions: list[FTItem] | list[int] | None = None,
        related_items: list[FTItem] | list[int] | None = None,
        fields: list[str] | None = None,
        previous: bool = False,
    ) -> None:
        """Initialize event filter."""
        self.params: dict[str, Any] = {"previous": previous}
        if top:
            self.params["top"] = top
        if after and (after_value := after.isoformat()):
            self.params["after"] = after_value
        if before and (before_value := before.isoformat()):
            self.params["after"] = before_value
        if sources:
            self.params["source"] = [
                source.ftitem_id if isinstance(source, FTItem) else source
                for source in sources
            ]
        if event_types:
            self.params["type"] = [
                event_type.ftitem_id
                if isinstance(event_type, FTEventType)
                else event_type
                for event_type in event_types
            ]
        if event_groups:
            self.params["group"] = [
                event_group.ftitem_id
                if isinstance(event_group, FTEventGroup)
                else event_group
                for event_group in event_groups
            ]
        if cardholders:
            self.params["cardholder"] = [
                cardholder.ftitem_id
                if isinstance(cardholder, FTCardholder)
                else cardholder
                for cardholder in cardholders
            ]
        if divisions:
            self.params["division"] = [
                division.ftitem_id if isinstance(division, FTItem) else division
                for division in divisions
            ]
        if related_items:
            self.params["relatedItem"] = [
                related_item.ftitem_id
                if isinstance(related_item, FTItem)
                else related_item
                for related_item in related_items
            ]
        if fields:
            event_fields = [field.name for field in EVENT_FIELDS]
            for field in fields:
                if (
                    not field.startswith("cardholder.pdf_")
                    and field not in event_fields
                ):
                    raise ValueError(f"'{field}' is not a valid field")
            self.params["fields"] = ",".join(fields)
